using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using KFTCTaxCAP.KioskSim.Net;
using KFTCTaxCAP.KioskSim.Preset;
using KFTCTaxCAP.KioskSim.Protocol;

namespace KFTCTaxCAP.KioskSim.Forms
{
    /// <summary>
    /// 메인 화면. 위쪽에 전문 선택 버튼(501008/800000/902614/999999), 가운데에 필드별 입력 그리드,
    /// 아래쪽에 raw 미리보기·전송 버튼·응답 필드 분해 그리드를 둔다.
    ///
    /// 이 클래스는 연동 샘플로도 쓰인다(README.md 참고) — 코드를 읽는 사람이 SPEC을
    /// 몰라도 "필드 계약(누가 무엇을 채우는가)"을 알 수 있게 그리드/주석을 짰다.
    /// </summary>
    public class MainForm : Form
    {
        // 그리드 열 인덱스(사람이 읽기 쉬운 이름으로 상수화).
        private const int ColNumber = 0;
        private const int ColName = 1;
        private const int ColRepresentation = 2;
        private const int ColLength = 3;
        private const int ColPosition = 4;
        private const int ColSetLocation = 5;
        private const int ColValue = 6;

        // 응답 필드 분해 그리드 열 인덱스.
        private const int RespColNumber = 0;
        private const int RespColName = 1;
        private const int RespColSetLocation = 2;
        private const int RespColRequestValue = 3;
        private const int RespColResponseValue = 4;

        /// <summary>CP949(전문 인코딩). 이 파일 안에서 독립적으로 정의한다.</summary>
        private static readonly Encoding Cp949 = Encoding.GetEncoding(949);

        private readonly Button _btnSelect501008;
        private readonly Button _btnSelect800000;
        private readonly Button _btnSelect902614;

        /// <summary>"직전 거래 상태 조회"(999999) 버튼 — 다른 3개 전문 버튼과 동일하게
        /// 스키마 선택 + 그리드 채우기만 담당한다(<see cref="SelectStatusInquirySchema"/>
        /// 참고). 실제 전송은 "전송" 버튼(<see cref="OnSendClickAsync"/>)이 한다.</summary>
        private readonly Button _btnStatusInquiry;

        private readonly Label _lblSelectedSchema;

        private readonly DataGridView _grid;
        private readonly TextBox _previewTextBox;
        private readonly Button _btnRefreshPreview;
        private readonly Button _btnSend;
        private readonly Button _btnSavePreset;
        private readonly Label _lblStatus;
        private readonly Label _lblResponseCode;
        private readonly Label _lblField51Warning;

        /// <summary>"직전 거래 상태 조회"(999999) 응답의 봉투 정보(#7/#14/#15/꼬리 길이)를 보여주는
        /// 라벨. 원거래 필드 분해는 기존 _responseGrid/_lblResponseCode/_responseTextBox를 그대로
        /// 재사용한다(조회 응답도 기존 파서로 분해할 수 있음을 보여 준다).</summary>
        private readonly Label _lblStatusInquiryEnvelope;

        private readonly DataGridView _responseGrid;
        private readonly TextBox _responseTextBox;

        /// <summary>현재 그리드에 떠 있는 전문 스키마(선택 전이면 null).</summary>
        private TelegramSchema? _currentSchema;

        /// <summary>
        /// 직전에 실제로 전송한 요청 본문(그리드가 그 뒤 편집되어도 흔들리지 않도록 전송 시점에
        /// 스냅샷해 둔다) + 그 스키마. 응답 필드 분해 화면이 "요청값 vs 응답값"을 나란히
        /// 보여줄 때 이 스냅샷을 쓴다(전송 후 그리드를 사용자가 계속 만질 수 있으므로 현재 그리드
        /// 값을 다시 읽으면 안 된다).
        /// </summary>
        private byte[]? _lastRequestBody;
        private TelegramSchema? _lastRequestSchema;

        /// <summary>
        /// "직전 거래 상태 조회"(999999) 버튼을 누른 시점의 <see cref="_lastRequestSchema"/>/
        /// <see cref="_lastRequestBody"/> 스냅샷. 조회 버튼도 다른 3개 전문 버튼과 동일하게
        /// 그리드만 채우고 실제 전송은 "전송" 버튼이 담당하므로, 조회 전문 전송 시
        /// <see cref="OnSendClickAsync"/>가 <see cref="_lastRequestSchema"/>/<see cref="_lastRequestBody"/>를 조회 전문(999999) 자신으로 덮어써 버린다 — 조회
        /// 응답을 원거래 스키마로 재분해할 때 "실제로 보냈던 원거래 요청값"과 비교하려면 그
        /// 값이 덮어써지기 전에 따로 보관해 둬야 한다(<see cref="ShowStatusInquiryResult"/> 참고).
        /// </summary>
        private byte[]? _priorTransactionBody;
        private TelegramSchema? _priorTransactionSchema;

        /// <summary>
        /// 세 전문 전부의 kiosk 편집 가능 필드 현재 값(전문타입 → 필드번호 → 값).
        /// 시작 시 프리셋/코드 기본값으로 채워지고, 사용자가 그리드를 편집할 때마다 즉시 갱신된다
        /// (탭을 오가도 값이 유지되게 하기 위함 — "직전 입력을 조용히 잃어버리지 않는다").
        /// "프리셋으로 저장" 버튼을 누르면 이 값 전체가 파일에 기록된다.
        /// </summary>
        private readonly Dictionary<string, Dictionary<int, string>> _currentValues = new Dictionary<string, Dictionary<int, string>>();

        /// <summary>그리드 셀 값 변경 이벤트가 "코드가 프로그램적으로 값을 채우는 중"에는 반응하지 않게 막는 플래그.</summary>
        private bool _suppressGridEvents;

        // ---- 전문 간 필드 연쇄(표는 Protocol/TelegramChainMap.cs) ----

        /// <summary>연쇄로 채워진 값 셀의 배경색(회색 = 잠김, 흰색 = 직접 입력과 구분).</summary>
        private static readonly Color ChainedCellColor = Color.FromArgb(214, 232, 255);

        /// <summary>
        /// 지금 연쇄로 채워져 있는 필드(전문타입, 필드번호). 이 집합에 든 셀만 <see cref="ChainedCellColor"/>로
        /// 칠한다. 앞 전문이 성공하면 추가, 실패하면 제거한다(<see cref="ApplyChainFromResponse"/>).
        /// </summary>
        private readonly HashSet<(string Tx, int Field)> _chainedFields = new HashSet<(string Tx, int Field)>();

        /// <summary>
        /// 목록에서 고르는 연쇄 필드(<see cref="TelegramChainConversion.SelectFirstFromList"/>, 예: 902614 할부 개월 수)의
        /// 선택 목록. 앞 전문 성공 시 받은 LIST를 잘라 넣고, 실패 시 지운다. 목록이 있는 필드만 그리드에서
        /// 콤보 셀로 그린다.
        /// </summary>
        private readonly Dictionary<(string Tx, int Field), IReadOnlyList<string>> _chainListOptions =
            new Dictionary<(string Tx, int Field), IReadOnlyList<string>>();

        /// <summary>목록 콤보 셀의 항목 하나 — 값(<see cref="Code"/>)은 2자리 코드, 표시(<see cref="Text"/>)는 "03 (3개월)".</summary>
        private sealed class ListOption
        {
            public string Code { get; }
            public string Text { get; }

            public ListOption(string code)
            {
                Code = code;
                string meaning = TelegramChainMap.DescribeInstallment(code);
                Text = meaning.Length > 0 ? $"{code} ({meaning})" : code;
            }
        }

        public MainForm()
        {
            Text = "KFTCTaxCAP 키오스크 시뮬레이터";
            Width = 1360;
            Height = 980;
            StartPosition = FormStartPosition.CenterScreen;
            Font = new Font("맑은 고딕", 9F);

            // ---- 시작 시 프리셋 로드(없으면 코드 기본값) ----
            var loaded = PresetStore.Load();
            InitializeCurrentValues(loaded);
            if (!loaded.ParsedOk && loaded.Warning != null)
            {
                // 파싱 실패는 화면이 뜬 뒤 사용자에게 알려도 늦지 않다(폴백은 이미 끝났다).
                this.Load += (s, e) => MessageBox.Show(this, loaded.Warning, "프리셋 파일 경고",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            // ---- 화면 구성 ----
            var topPanel = new Panel { Dock = DockStyle.Top, Height = 56, Padding = new Padding(8) };
            _btnSelect501008 = new Button { Text = "501008\n국고 상세 고지내역 조회", Width = 220, Height = 40, Left = 8, Top = 8 };
            _btnSelect800000 = new Button { Text = "800000\n카드 정보 조회", Width = 220, Height = 40, Left = 236, Top = 8 };
            _btnSelect902614 = new Button { Text = "902614\n국고 신용카드 승인요청", Width = 220, Height = 40, Left = 464, Top = 8 };
            _btnStatusInquiry = new Button { Text = "직전 거래\n상태 조회(999999)", Width = 150, Height = 40, Left = 692, Top = 8 };
            _lblSelectedSchema = new Label
            {
                Text = "선택된 전문: 없음",
                Left = 852,
                Top = 18,
                Width = 400,
                Font = new Font("맑은 고딕", 10F, FontStyle.Bold),
            };
            topPanel.Controls.Add(_btnSelect501008);
            topPanel.Controls.Add(_btnSelect800000);
            topPanel.Controls.Add(_btnSelect902614);
            topPanel.Controls.Add(_btnStatusInquiry);
            topPanel.Controls.Add(_lblSelectedSchema);

            var bottomPanel = new Panel { Dock = DockStyle.Bottom, Height = 560, Padding = new Padding(8) };

            var previewLabel = new Label { Text = "보낼 전문 raw ASCII 미리보기(CP949 디코딩):", Dock = DockStyle.Top, Height = 18 };
            _previewTextBox = new TextBox
            {
                Multiline = true,
                ReadOnly = true,
                ScrollBars = ScrollBars.Both,
                WordWrap = false,
                Dock = DockStyle.Top,
                Height = 90,
                Font = new Font("Consolas", 9F),
                BackColor = Color.WhiteSmoke,
            };

            var buttonRow = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 36, FlowDirection = FlowDirection.LeftToRight };
            _btnRefreshPreview = new Button { Text = "미리보기 갱신", Width = 110 };
            _btnSend = new Button { Text = "전송", Width = 110, Enabled = false };
            _btnSavePreset = new Button { Text = "현재 값을 프리셋으로 저장", Width = 180 };
            buttonRow.Controls.Add(_btnRefreshPreview);
            buttonRow.Controls.Add(_btnSend);
            buttonRow.Controls.Add(_btnSavePreset);

            _lblStatus = new Label { Text = "대기 중.", Dock = DockStyle.Top, Height = 20, ForeColor = Color.DarkBlue };

            var responseLabel = new Label { Text = "응답 결과:", Dock = DockStyle.Top, Height = 18, Font = new Font("맑은 고딕", 9F, FontStyle.Bold) };
            _lblResponseCode = new Label
            {
                Text = "#7 응답 코드: (아직 응답 없음)",
                Dock = DockStyle.Top,
                Height = 20,
                ForeColor = Color.Black,
            };
            _lblField51Warning = new Label
            {
                // 902614가 아닌 전문일 때는 해당 없음으로 비워 둔다 — ShowFieldDecomposition이 채운다.
                Text = string.Empty,
                Dock = DockStyle.Top,
                Height = 20,
                ForeColor = Color.DarkGreen,
                Font = new Font("맑은 고딕", 9F, FontStyle.Bold),
            };

            _lblStatusInquiryEnvelope = new Label
            {
                Text = string.Empty,
                Dock = DockStyle.Top,
                Height = 20,
                ForeColor = Color.DarkSlateBlue,
                Font = new Font("맑은 고딕", 9F, FontStyle.Bold),
            };

            var responseGridLabel = new Label
            {
                Text = "응답 필드 분해(값(요청) vs 값(응답), 달라진 셀은 노란색으로 강조):",
                Dock = DockStyle.Top,
                Height = 18,
            };

            // 필드 분해 그리드(위, 남는 공간의 대부분)와 raw ASCII 미리보기(아래, 고정 높이)를
            // 위아래로 나눈다 — SplitContainer 하나가 이 bottomPanel의 유일한 Fill 대상이 된다.
            var responseSplit = new SplitContainer
            {
                Dock = DockStyle.Fill,
                Orientation = Orientation.Horizontal,
                SplitterWidth = 6,
            };

            _responseGrid = new DataGridView
            {
                Dock = DockStyle.Fill,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AllowUserToResizeRows = false,
                ReadOnly = true,
                RowHeadersVisible = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None,
                SelectionMode = DataGridViewSelectionMode.CellSelect,
                EditMode = DataGridViewEditMode.EditProgrammatically,
            };
            _responseGrid.Columns.Add("respColNumber", "#번호");
            _responseGrid.Columns.Add("respColName", "필드명");
            _responseGrid.Columns.Add("respColSetLocation", "SET 장소");
            _responseGrid.Columns.Add("respColRequestValue", "값(요청)");
            _responseGrid.Columns.Add("respColResponseValue", "값(응답)");
            _responseGrid.Columns[RespColNumber].Width = 55;
            _responseGrid.Columns[RespColName].Width = 260;
            _responseGrid.Columns[RespColSetLocation].Width = 150;
            _responseGrid.Columns[RespColRequestValue].Width = 300;
            _responseGrid.Columns[RespColResponseValue].Width = 300;
            _responseGrid.Columns[RespColResponseValue].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

            var rawResponseLabel = new Label { Text = "응답 본문 raw ASCII(CP949 디코딩):", Dock = DockStyle.Top, Height = 18 };
            _responseTextBox = new TextBox
            {
                Multiline = true,
                ReadOnly = true,
                ScrollBars = ScrollBars.Both,
                WordWrap = false,
                Dock = DockStyle.Fill,
                Font = new Font("Consolas", 9F),
                BackColor = Color.WhiteSmoke,
            };

            responseSplit.Panel1.Controls.Add(_responseGrid);
            responseSplit.Panel1.Controls.Add(responseGridLabel);
            responseSplit.Panel2.Controls.Add(_responseTextBox);
            responseSplit.Panel2.Controls.Add(rawResponseLabel);

            // Dock 순서 주의: 나중에 추가한 컨트롤일수록 레이아웃에서 우선 배치된다.
            // responseSplit(Fill)을 가장 먼저 추가해 나머지 Top-docked 컨트롤들이 위쪽부터
            // 자리를 잡고, 그 뒤 responseSplit이 남은 공간을 채우게 한다.
            bottomPanel.Controls.Add(responseSplit);
            bottomPanel.Controls.Add(_lblField51Warning);
            bottomPanel.Controls.Add(_lblResponseCode);
            bottomPanel.Controls.Add(_lblStatusInquiryEnvelope);
            bottomPanel.Controls.Add(responseLabel);
            bottomPanel.Controls.Add(_lblStatus);
            bottomPanel.Controls.Add(buttonRow);
            bottomPanel.Controls.Add(_previewTextBox);
            bottomPanel.Controls.Add(previewLabel);

            // SplitContainer 초기 SplitterDistance는 핸들 생성(레이아웃 확정) 후에 설정해야
            // "SplitterDistance가 허용 범위를 벗어났다" 예외를 피할 수 있다.
            responseSplit.HandleCreated += (s, e) =>
            {
                if (responseSplit.Height > 220)
                    responseSplit.SplitterDistance = responseSplit.Height - 160;
            };

            _grid = new DataGridView
            {
                Dock = DockStyle.Fill,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AllowUserToResizeRows = false,
                RowHeadersVisible = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None,
                SelectionMode = DataGridViewSelectionMode.CellSelect,
                EditMode = DataGridViewEditMode.EditOnKeystrokeOrF2,
            };
            _grid.Columns.Add("colNumber", "#번호");
            _grid.Columns.Add("colName", "필드명");
            _grid.Columns.Add("colRepresentation", "표현");
            _grid.Columns.Add("colLength", "길이");
            _grid.Columns.Add("colPosition", "POSITION");
            _grid.Columns.Add("colSetLocation", "SET 장소");
            _grid.Columns.Add("colValue", "값");

            _grid.Columns[ColNumber].Width = 55;
            _grid.Columns[ColName].Width = 260;
            _grid.Columns[ColRepresentation].Width = 60;
            _grid.Columns[ColLength].Width = 55;
            _grid.Columns[ColPosition].Width = 70;
            _grid.Columns[ColSetLocation].Width = 210; // 연쇄 필드는 "kiosk ← 501008 응답 #30+#31+#32"처럼 출처를 보여준다.
            _grid.Columns[ColValue].Width = 280;
            _grid.Columns[ColValue].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

            foreach (DataGridViewColumn col in _grid.Columns)
            {
                if (col.Index != ColValue)
                    col.ReadOnly = true; // 값 열 외에는 항상 읽기 전용(SET 장소와 무관하게 표시 전용).
            }

            // 순서: Fill(그리드)을 먼저 추가하고 Top/Bottom을 나중에 추가해야 Top/Bottom이
            // 자기 영역을 먼저 차지하고 그리드가 남는 공간을 채운다(위 bottomPanel과 동일한 이유).
            Controls.Add(_grid);
            Controls.Add(bottomPanel);
            Controls.Add(topPanel);

            // ---- 이벤트 연결 ----
            _btnSelect501008.Click += (s, e) => SelectSchema(TelegramSchemas.Notice501008);
            _btnSelect800000.Click += (s, e) => SelectSchema(TelegramSchemas.CardInfo800000);
            _btnSelect902614.Click += (s, e) => SelectSchema(TelegramSchemas.CardApproval902614);
            _btnRefreshPreview.Click += (s, e) => UpdatePreview();
            _btnSavePreset.Click += (s, e) => SavePreset();
            _btnSend.Click += async (s, e) => await OnSendClickAsync();
            _btnStatusInquiry.Click += (s, e) => SelectStatusInquirySchema();
            _grid.CellValueChanged += Grid_CellValueChanged;
            _grid.CurrentCellDirtyStateChanged += (s, e) =>
            {
                // 텍스트 셀 편집 중 커밋되지 않은 값도 즉시 CellValueChanged로 반영되게 한다
                // (기본 동작은 포커스를 옮겨야 커밋된다 — 미리보기를 실시간처럼 보이게 하려면 이 처리가 필요).
                // 목록 콤보 셀은 제외한다 — 직접 입력 중인 글자("6" → "63")를 한 글자마다 확정하지 않고,
                // 목록 선택(ListCombo_SelectionChangeCommitted)이나 셀을 떠날 때 확정한다.
                if (_grid.IsCurrentCellDirty && !(_grid.CurrentCell is DataGridViewComboBoxCell))
                    _grid.CommitEdit(DataGridViewDataErrorContexts.Commit);
            };
            _grid.EditingControlShowing += Grid_EditingControlShowing;
            _grid.CellEndEdit += Grid_CellEndEdit;
            _grid.CellParsing += Grid_CellParsing;
            _grid.DataError += Grid_DataError;
        }

        /// <summary>세 전문 전부의 kiosk 편집 가능 필드 값을 프리셋/코드 기본값으로 초기화한다.</summary>
        private void InitializeCurrentValues(PresetStore.LoadResult loaded)
        {
            _currentValues["501008"] = PresetStore.BuildInitialValues(loaded, TelegramSchemas.Notice501008);
            _currentValues["800000"] = PresetStore.BuildInitialValues(loaded, TelegramSchemas.CardInfo800000);
            _currentValues["902614"] = PresetStore.BuildInitialValues(loaded, TelegramSchemas.CardApproval902614);
            _currentValues[TelegramSchemas.StatusInquiryTransactionType] =
                PresetStore.BuildInitialValues(loaded, TelegramSchemas.StatusInquiryRequest);
        }

        /// <summary>전문 버튼을 눌렀을 때: 스키마 전환 + 그리드 재구성 + 미리보기 갱신.</summary>
        private void SelectSchema(TelegramSchema schema)
        {
            _currentSchema = schema;
            _lblSelectedSchema.Text = $"선택된 전문: {schema.TxType} (총 {schema.TotalLength}바이트, 필드 {schema.Fields.Count}개)";
            _btnSend.Enabled = true;
            LoadGridForSchema(schema);
            UpdatePreview();
            ClearResponseDisplay(); // 전문을 바꾸면 이전 전문의 응답 분해 결과가 화면에 남아 있으면 안 된다.
        }

        /// <summary>응답 관련 표시(필드 분해 그리드/코드 해설/#51 경고/raw ASCII/조회 봉투)를 전부 비운다.</summary>
        private void ClearResponseDisplay()
        {
            _responseGrid.Rows.Clear();
            _lblResponseCode.Text = "#7 응답 코드: (아직 응답 없음)";
            _lblResponseCode.ForeColor = Color.Black;
            _lblField51Warning.Text = string.Empty;
            _responseTextBox.Text = string.Empty;
            _lblStatusInquiryEnvelope.Text = string.Empty;
        }

        /// <summary>스키마의 필드 전체를 SPEC 순서(번호 오름차순)로 그리드에 나열한다.</summary>
        private void LoadGridForSchema(TelegramSchema schema)
        {
            _suppressGridEvents = true;
            try
            {
                _grid.Rows.Clear();
                var byNumber = _currentValues[schema.TxType];

                foreach (var field in schema.Fields.OrderBy(f => f.Number))
                {
                    // AlwaysBlank 필드(FILLER/예비 정보 FIELD, #5 상태 코드 등)는 SetLocation이
                    // Kiosk여도 편집을 막는다 — 정의된 유효값이 없어 편집 가능하게 열어두면
                    // 무엇을 넣어야 하는지 헷갈리고 잘못된 값을 실수로 채워 보낼 위험만 커진다
                    // (TelegramField.AlwaysBlank 문서 참고).
                    // ZeroFilled 필드(서버 요구 — kiosk·원캡이 안 채우는 N 필드는 0 채움)도 편집을 막고,
                    // 값 칸에 0(필드 길이만큼)을 그대로 보여준다 — 보이는 값이 곧 전송되는 값이다.
                    bool editable = field.SetLocation == TelegramSetLocation.Kiosk && !field.AlwaysBlank && !field.ZeroFilled;
                    string valueCellText = field.ZeroFilled
                        ? field.FixedValue
                        : editable && byNumber.TryGetValue(field.Number, out var v) ? v : string.Empty;

                    var chainEntry = TelegramChainMap.FindEntry(schema.TxType, field.Number);

                    int rowIndex = _grid.Rows.Add(
                        field.Number,
                        field.Name,
                        field.Representation.ToString(),
                        field.Length,
                        field.Position,
                        chainEntry != null ? DescribeChainSource(chainEntry) : DescribeSetLocation(field),
                        valueCellText);

                    var row = _grid.Rows[rowIndex];
                    row.Tag = field;

                    // 목록에서 고르는 연쇄 필드(예: 902614 할부 개월 수)는 앞 전문에서 목록을 받았을 때만
                    // 콤보 셀로 바꾼다. 목록이 없으면(앞 전문 응답 전/실패) 빈 텍스트 셀 그대로다.
                    if (editable && _chainListOptions.TryGetValue((schema.TxType, field.Number), out var options))
                    {
                        row.Cells[ColValue] = CreateListCell(options, valueCellText);
                        row.Cells[ColValue].Value = valueCellText.Length > 0 ? valueCellText : null;
                    }

                    row.Cells[ColValue].ReadOnly = !editable;
                    if (!editable)
                    {
                        row.Cells[ColValue].Style.BackColor = Color.LightGray;
                        row.Cells[ColValue].Style.ForeColor = Color.DimGray;
                        row.DefaultCellStyle.BackColor = Color.WhiteSmoke;
                    }
                    else
                    {
                        row.Cells[ColValue].Style.BackColor = ValueCellColor(schema.TxType, field.Number);
                    }
                }
            }
            finally
            {
                _suppressGridEvents = false;
            }
        }

        /// <summary>
        /// AlwaysBlank인 Kiosk 필드는 "kiosk (직접 입력)"이 아니라 별도 문구로 보여준다 — 배경색은
        /// 다른 잠긴 필드(OneCap/InternetGiro/Van 담당)와 같은 회색이지만, "왜 잠겼는지"가 달라서
        /// (남이 채우는 게 아니라 애초에 값이 필요 없어서) 문구를 구분해 둔다.
        /// </summary>
        private static string DescribeSetLocation(TelegramField field)
        {
            if (field.ZeroFilled)
                return "서버 요구: 0 고정 (편집 불가)";
            if (field.SetLocation == TelegramSetLocation.Kiosk && field.AlwaysBlank)
                return "kiosk (공백 고정, 편집 불가)";
            return DescribeSetLocation(field.SetLocation);
        }

        /// <summary>
        /// 연쇄 필드의 SET 장소 열 문구 — 값이 어디서 오는지를 그대로 보여준다
        /// (예: "kiosk ← 501008 응답 #30+#31+#32", "kiosk ← 이 전문 #27+#28").
        /// </summary>
        private static string DescribeChainSource(TelegramChainEntry entry)
        {
            string fields = "#" + string.Join("+#", entry.SourceFields);
            return entry.IsWithinSameRequest
                ? $"kiosk ← 이 전문 {fields}"
                : $"kiosk ← {entry.SourceTx} 응답 {fields}";
        }

        /// <summary>편집 가능한 값 셀의 배경색 — 연쇄로 채워진 필드면 연쇄 색, 아니면 흰색.</summary>
        private Color ValueCellColor(string txType, int fieldNumber)
            => _chainedFields.Contains((txType, fieldNumber)) ? ChainedCellColor : Color.White;

        /// <summary>
        /// 목록 콤보 셀을 만든다. 항목의 값은 2자리 코드, 표시는 "03 (3개월)" 형식이다. 지금 값이 목록에
        /// 없으면(사용자가 직접 입력한 포인트 납부 값 "63" 등) 그 값도 항목으로 넣어 그대로 보이게 한다.
        /// </summary>
        private static DataGridViewComboBoxCell CreateListCell(IReadOnlyList<string> codes, string currentValue)
        {
            var cell = new DataGridViewComboBoxCell
            {
                DisplayMember = nameof(ListOption.Text),
                ValueMember = nameof(ListOption.Code),
                FlatStyle = FlatStyle.Flat,
            };
            foreach (string code in codes)
                cell.Items.Add(new ListOption(code));
            if (currentValue.Length > 0 && !codes.Contains(currentValue))
                cell.Items.Add(new ListOption(currentValue));
            return cell;
        }

        private static string DescribeSetLocation(TelegramSetLocation location)
        {
            switch (location)
            {
                case TelegramSetLocation.Kiosk: return "kiosk (직접 입력)";
                case TelegramSetLocation.OneCap: return "원캡이 채움";
                case TelegramSetLocation.InternetGiro: return "인터넷지로가 채움";
                case TelegramSetLocation.Van: return "VAN이 채움";
                default: return location.ToString();
            }
        }

        /// <summary>값 열이 편집될 때마다 <see cref="_currentValues"/>에 즉시 반영하고 미리보기를 갱신한다.</summary>
        private void Grid_CellValueChanged(object? sender, DataGridViewCellEventArgs e)
        {
            if (_suppressGridEvents || _currentSchema == null)
                return;
            if (e.RowIndex < 0 || e.ColumnIndex != ColValue)
                return;

            var row = _grid.Rows[e.RowIndex];
            var field = (TelegramField)row.Tag!;
            if (field.SetLocation != TelegramSetLocation.Kiosk || field.AlwaysBlank || field.ZeroFilled)
                return; // 읽기 전용 셀은 편집될 수 없지만, 방어적으로 한 번 더 확인(AlwaysBlank도 동일).

            string value = Convert.ToString(row.Cells[ColValue].Value) ?? string.Empty;
            _currentValues[_currentSchema.TxType][field.Number] = value;

            // 같은 전문 안에서 계산하는 연쇄 필드(예: 902614 총 납부 금액 = 납부 세액 + 수수료)는
            // 입력 필드를 사용자가 고쳐도 다시 계산한다.
            RecomputeWithinRequestEntries(_currentSchema.TxType);

            UpdatePreview();
        }

        // ------------------------------------------------------------------------------------
        // 목록 콤보 셀(902614 할부 개월 수) — 목록 선택 + 직접 입력
        //
        // 할부 개월 수는 800000 응답의 카드 할부개월 LIST에서 고른다. 단, 포인트 납부는 목록에 없다 —
        // 포인트로 납부하려면 "할부 개월 수 + 60"을 직접 입력한다(포인트 일시불 = "60", 포인트 3개월 = "63").
        // DataGridViewComboBoxCell은 기본적으로 목록 밖 값을 받지 않으므로 WinForms 표준 방식으로 직접
        // 입력을 허용한다:
        //   1) 편집 컨트롤의 DropDownStyle을 DropDown으로 바꿔 글자를 칠 수 있게 하고(EditingControlShowing),
        //   2) 글자가 바뀌면 셀을 "변경됨"으로 표시해 셀을 떠날 때 확정되게 하고(ListCombo_TextChanged),
        //   3) 표시 문구("03 (3개월)")나 입력 글자("63")에서 2자리 코드만 꺼내 셀 값으로 삼고(CellParsing),
        //   4) 편집이 끝난 뒤 그 코드가 목록에 없으면 항목으로 추가해 "63 (포인트 3개월)"로 보이게 한다(CellEndEdit).
        //      ※ 편집 도중(CellValidating 등)에 셀 항목을 바꾸면 WinForms가 편집 콤보를 원래 값으로 다시
        //        초기화해 방금 친 글자가 사라진다 — 그래서 항목 추가는 반드시 편집이 끝난 뒤에 한다.
        // 그래서 전문에는 언제나 코드만 들어가고 "(3개월)" 같은 표시 문구는 섞이지 않는다.
        // ------------------------------------------------------------------------------------

        private void Grid_EditingControlShowing(object? sender, DataGridViewEditingControlShowingEventArgs e)
        {
            if (e.Control is ComboBox combo && _grid.CurrentCell is DataGridViewComboBoxCell)
            {
                combo.DropDownStyle = ComboBoxStyle.DropDown; // 직접 입력 허용
                // 편집 컨트롤은 셀끼리 재사용되므로 중복 구독을 막기 위해 먼저 뺀다.
                combo.SelectionChangeCommitted -= ListCombo_SelectionChangeCommitted;
                combo.SelectionChangeCommitted += ListCombo_SelectionChangeCommitted;
                combo.TextChanged -= ListCombo_TextChanged;
                combo.TextChanged += ListCombo_TextChanged;
            }
        }

        /// <summary>
        /// 직접 입력한 글자도 "값이 바뀌었다"고 그리드에 알린다. 콤보 편집 컨트롤은 목록 선택이 바뀔 때만
        /// 이 신호를 보내므로, 이 처리가 없으면 직접 친 "63"이 셀을 떠날 때 버려진다. (한 글자마다 확정하지는
        /// 않는다 — 확정은 셀을 떠날 때 CellParsing이 한다.)
        /// </summary>
        private void ListCombo_TextChanged(object? sender, EventArgs e)
        {
            if (sender is IDataGridViewEditingControl editingControl
                && _grid.IsCurrentCellInEditMode && _grid.CurrentCell is DataGridViewComboBoxCell)
            {
                // 콤보 편집 컨트롤이 목록 선택 때 스스로 하는 것과 같은 두 가지 표시를 한다.
                editingControl.EditingControlValueChanged = true;
                _grid.NotifyCurrentCellDirty(true);
            }
        }

        /// <summary>목록에서 항목을 고르면 바로 확정한다(콤보 글자가 선택 항목으로 바뀐 뒤에 확정하도록 한 박자 늦춘다).</summary>
        private void ListCombo_SelectionChangeCommitted(object? sender, EventArgs e)
        {
            BeginInvoke(new Action(() =>
            {
                if (_grid.IsCurrentCellInEditMode && _grid.CurrentCell is DataGridViewComboBoxCell)
                    _grid.CommitEdit(DataGridViewDataErrorContexts.Commit);
            }));
        }

        /// <summary>
        /// 편집이 끝난 목록 콤보 셀의 값(직접 입력한 코드 등)이 목록에 없으면 항목으로 추가한다 — 그래야 셀이
        /// 그 값을 "63 (포인트 3개월)"처럼 표시할 수 있다. 값의 형식(숫자 2자리 등)은 막지 않는다 — 전문을
        /// 만들 때 길이 검사에 맡긴다.
        /// </summary>
        private void Grid_CellEndEdit(object? sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex != ColValue)
                return;
            if (!(_grid.Rows[e.RowIndex].Cells[ColValue] is DataGridViewComboBoxCell cell))
                return;

            string code = Convert.ToString(cell.Value) ?? string.Empty;
            if (code.Length > 0 && !cell.Items.Cast<ListOption>().Any(o => o.Code == code))
                cell.Items.Add(new ListOption(code));
        }

        private void Grid_CellParsing(object? sender, DataGridViewCellParsingEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex != ColValue)
                return;
            if (!(_grid.Rows[e.RowIndex].Cells[ColValue] is DataGridViewComboBoxCell))
                return;

            string code = ExtractListCode(Convert.ToString(e.Value));
            e.Value = code.Length > 0 ? code : null;
            e.ParsingApplied = true;
        }

        /// <summary>"03 (3개월)" → "03", "63" → "63". 첫 공백이나 괄호 앞까지가 코드다.</summary>
        private static string ExtractListCode(string? text)
        {
            string trimmed = (text ?? string.Empty).Trim();
            int end = trimmed.IndexOfAny(new[] { ' ', '(' });
            return end < 0 ? trimmed : trimmed.Substring(0, end);
        }

        /// <summary>
        /// 셀 값 표시/변환 오류가 나도 기본 오류 대화상자를 띄우지 않고 상태 표시줄로만 알린다(안전망 —
        /// 위 콤보 처리로 정상 경로에서는 발생하지 않는다).
        /// </summary>
        private void Grid_DataError(object? sender, DataGridViewDataErrorEventArgs e)
        {
            e.ThrowException = false;
            _lblStatus.Text = $"그리드 값 오류(행 {e.RowIndex}): {e.Exception?.Message}";
            _lblStatus.ForeColor = Color.DarkRed;
        }

        /// <summary>
        /// 현재 그리드 값으로 <see cref="TelegramBuffer"/>를 만든다. 값이 빈 문자열인 필드는
        /// <see cref="TelegramBuffer.Write"/>를 아예 호출하지 않는다 — tools/spec_client.ps1의
        /// Set-Field가 빈 값이면 건너뛰는 것과 동일한 규칙이다(빈 값 = "이 필드는 안 쓴다", 버퍼
        /// 초기화값인 space로 남는다).
        /// </summary>
        private TelegramBuffer BuildBufferFromGrid()
        {
            if (_currentSchema == null)
                throw new InvalidOperationException("전문이 선택되지 않았다.");

            var buffer = new TelegramBuffer(_currentSchema);
            foreach (DataGridViewRow row in _grid.Rows)
            {
                var field = (TelegramField)row.Tag!;
                string value = Convert.ToString(row.Cells[ColValue].Value) ?? string.Empty;
                if (value.Length == 0)
                    continue;
                buffer.Write(field.Number, value);
            }
            return buffer;
        }

        private void UpdatePreview()
        {
            if (_currentSchema == null)
            {
                _previewTextBox.Text = string.Empty;
                return;
            }

            try
            {
                var buffer = BuildBufferFromGrid();
                byte[] body = buffer.ToBytes();
                _previewTextBox.Text = Cp949.GetString(body);
            }
            catch (Exception ex)
            {
                // 길이 초과 등 TelegramBuffer.Write 예외를 미리보기 단계에서 사람이 바로 볼 수 있게.
                _previewTextBox.Text = $"[미리보기 생성 실패] {ex.Message}";
            }
        }

        private void SavePreset()
        {
            try
            {
                PresetStore.Save(_currentValues);
                _lblStatus.Text = $"프리셋 저장 완료 ({PresetStore.PresetFilePath}).";
                _lblStatus.ForeColor = Color.DarkGreen;
            }
            catch (Exception ex)
            {
                _lblStatus.Text = $"프리셋 저장 실패: {ex.Message}";
                _lblStatus.ForeColor = Color.DarkRed;
                MessageBox.Show(this, ex.Message, "프리셋 저장 실패", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async System.Threading.Tasks.Task OnSendClickAsync()
        {
            if (_currentSchema == null)
                return;

            TelegramBuffer buffer;
            try
            {
                buffer = BuildBufferFromGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "전문 생성 실패", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // 응답 필드 분해가 "지금 그리드 값"이 아니라 "실제로 보낸 값"과 비교해야 하므로
            // 전송 시점의 요청 본문을 스냅샷해 둔다(전송 후에도 사용자가 그리드를 계속 편집할 수 있음).
            _lastRequestBody = buffer.ToBytes();
            _lastRequestSchema = _currentSchema;

            byte[] frame = TelegramCodec.Encode(buffer.ToBytes());
            UpdatePreview();
            ClearResponseDisplay();

            // 앞 전문 응답을 받지 않아 비어 있는 연쇄 필드가 있으면 알려만 준다 — 전송은 막지 않는다
            // (빈 칸 그대로 보냈을 때 서버가 어떤 오류를 돌려주는지 보는 것도 점검 대상이다).
            string emptyChainNotice = DescribeEmptyChainFields(_currentSchema.TxType);

            SetSendingState(true, _currentSchema.TxType);
            _lblStatus.Text += emptyChainNotice;
            try
            {
                // OneCapClient.SendAsync의 onElapsed 콜백은 백그라운드 스레드에서 호출된다
                // (Net/OneCapClient.cs 클래스 주석 참고) — 반드시 Control.Invoke로 UI 스레드로
                // 넘겨야 한다. 폼이 이미 닫히는 중이면 Invoke가 예외를 던질 수 있어 IsDisposed로 방어한다.
                Action<TimeSpan> onElapsed = elapsed =>
                {
                    if (IsDisposed || !IsHandleCreated)
                        return;
                    try
                    {
                        BeginInvoke(new Action(() =>
                        {
                            if (!IsDisposed)
                                _lblStatus.Text = $"응답 대기 중… ({elapsed.TotalSeconds:F1}초)" + emptyChainNotice;
                        }));
                    }
                    catch (ObjectDisposedException)
                    {
                        // 폼 종료 경합 — 무시.
                    }
                };

                OneCapClientResult result = await OneCapClient.SendAsync(frame, onElapsed);
                ShowResult(result);
                _lblStatus.Text += emptyChainNotice;
            }
            finally
            {
                SetSendingState(false, _currentSchema.TxType);
            }
        }

        /// <summary>
        /// 버튼 활성/비활성만 담당한다. <c>sending=false</c>일 때 상태 라벨을 "대기 중."으로
        /// 덮어쓰지 않는다 — <see cref="OnSendClickAsync"/>가 직전에 <see cref="ShowResult"/>로
        /// 남긴 실패 원인 메시지(연결 거부/타임아웃 등)가 finally 블록에서 지워지면 안 되기 때문이다
        /// (<see cref="ShowResult"/>는 응답 본문이 없을 때 "위 상태 메시지 참고"라고 안내한다).
        /// </summary>
        private void SetSendingState(bool sending, string txType)
        {
            _btnSend.Enabled = !sending;
            _btnSelect501008.Enabled = !sending;
            _btnSelect800000.Enabled = !sending;
            _btnSelect902614.Enabled = !sending;
            _btnStatusInquiry.Enabled = !sending;
            if (sending)
            {
                _lblStatus.ForeColor = Color.DarkBlue;
                _lblStatus.Text = $"{txType} 전송 중… 응답 대기 중… (0.0초)";
            }
        }

        private void ShowResult(OneCapClientResult result)
        {
            _lblStatus.Text = $"[결과: {result.Kind}] {result.Message}" +
                (result.Error != null ? $" / 예외: {result.Error.GetType().Name}: {result.Error.Message}" : string.Empty);
            _lblStatus.ForeColor = result.Kind == OneCapClientResultKind.Success ? Color.DarkGreen : Color.DarkRed;

            if (result.Kind != OneCapClientResultKind.Success || result.ResponseBody == null)
            {
                // 전송(프레이밍) 자체가 실패한 경우 — 응답 본문이 없으므로 필드 분해/코드 해설도 없다.
                // 이 실패는 TelegramCodec/OneCapClient 계층 문제이지, SPEC #7 응답 코드 체계와는 다른 층이다.
                ClearResponseDisplay();
                _lblResponseCode.Text = "#7 응답 코드: (응답 본문 없음 — 전송/수신 자체가 실패했다. 위 상태 메시지 참고)";
                _lblResponseCode.ForeColor = Color.DarkRed;

                // 응답을 받지 못한 것도 연쇄에서는 "실패"다 — 그 전문에서 온 연쇄 값을 비운다.
                // (999999 직전 거래 조회는 연쇄와 무관하다.)
                if (_lastRequestSchema != null && _lastRequestSchema.TxType != TelegramSchemas.StatusInquiryTransactionType)
                    ApplyChainFromResponse(_lastRequestSchema.TxType, null);
                return;
            }

            _responseTextBox.Text = Cp949.GetString(result.ResponseBody);

            if (_lastRequestSchema == null || _lastRequestBody == null)
            {
                // 방어적 분기 — OnSendClickAsync가 항상 먼저 스냅샷을 남기므로 실제로는 발생하지 않는다.
                _lblResponseCode.Text = "#7 응답 코드: (직전 요청 스냅샷을 찾을 수 없어 분해할 수 없음)";
                _lblResponseCode.ForeColor = Color.DarkRed;
                return;
            }

            // "직전 거래 상태 조회"(999999)는 응답 구조가 다르다(공통부 70 + #14/#15 + 가변 원거래
            // 원문) — 다른 3전문과 같은 고정 스키마 분해(ShowFieldDecomposition)를 바로 쓸 수 없어
            // 전용 파서(ShowStatusInquiryResult)로 분기한다.
            if (_lastRequestSchema.TxType == TelegramSchemas.StatusInquiryTransactionType)
            {
                ShowStatusInquiryResult(result.ResponseBody);
                return;
            }

            ShowFieldDecomposition(_lastRequestSchema, _lastRequestBody, result.ResponseBody);

            // 응답을 뒤 전문 요청 필드로 연쇄한다(#7 = "000"이면 채우고, 아니면 비운다).
            ApplyChainFromResponse(_lastRequestSchema.TxType, result.ResponseBody);
        }

        // ====================================================================================
        // 전문 간 필드 연쇄 — 키오스크가 구현해야 하는 핵심 로직
        //
        // 규칙 표는 Protocol/TelegramChainMap.cs 한 곳에 있고, 화면은 아래 두 함수로 그 표를 적용한다.
        //   - ApplyChainFromResponse        : 앞 전문 응답을 받았을 때(또는 받지 못했을 때) 한 번 호출
        //   - RecomputeWithinRequestEntries : 같은 전문 안에서 계산하는 항목(총 납부 금액 등) 재계산
        // 필드 번호는 여기 하드코딩하지 않는다 — 전부 표에서 얻는다.
        // ====================================================================================

        /// <summary>
        /// 앞 전문(<paramref name="sourceTx"/>)의 응답으로 뒤 전문 요청 필드를 채우거나 비운다.
        /// <list type="number">
        /// <item>성공 판정: 응답 본문이 있고, 길이가 전문 길이와 같고, 응답 <c>#7</c> 응답 코드가 <c>"000"</c>.</item>
        /// <item>성공이면 표에서 출처가 <paramref name="sourceTx"/>인 항목을 계산해 대상 전문 값에 쓰고 "연쇄로 채워짐"
        ///       표시(색)를 단다. 사용자가 그 사이 고친 값도 덮어쓴다.</item>
        /// <item>실패(<c>#7</c> ≠ <c>"000"</c>, 응답 없음, 길이 불일치)면 같은 항목의 값을 빈 칸으로 되돌리고 표시를 지운다.
        ///       다른 전문에서 온 값은 건드리지 않는다.</item>
        /// <item>이어서 같은 전문 안에서 계산하는 항목(예: 902614 총 납부 금액)을 다시 계산한다.</item>
        /// </list>
        /// 지금 화면에 보이지 않는 전문의 값도 갱신된다(전문 버튼을 누르면 갱신된 값으로 다시 그려진다).
        /// </summary>
        /// <param name="sourceTx">방금 보낸 전문(501008/800000/902614).</param>
        /// <param name="responseBody">응답 본문. 전송/수신 자체가 실패했으면 null.</param>
        private void ApplyChainFromResponse(string sourceTx, byte[]? responseBody)
        {
            // 1) 성공 판정
            TelegramSchema sourceSchema = TelegramSchemas.ByTxType(sourceTx);
            TelegramBuffer? response = null;
            if (responseBody != null && responseBody.Length == sourceSchema.TotalLength)
            {
                var parsed = new TelegramBuffer(sourceSchema, responseBody);
                if (parsed.Read(7).Trim() == "000")
                    response = parsed;
            }

            // 2)·3) 출처가 이 전문 응답인 항목을 채우거나 비운다.
            var targetTxs = new HashSet<string>();
            int filledCount = 0;
            int clearedCount = 0;
            foreach (var entry in TelegramChainMap.Entries)
            {
                if (entry.IsWithinSameRequest || entry.SourceTx != sourceTx)
                    continue;

                var key = (entry.TargetTx, entry.TargetField);
                targetTxs.Add(entry.TargetTx);

                if (response != null)
                {
                    var sourceValues = entry.SourceFields.Select(n => response.Read(n)).ToList();
                    int targetLength = TelegramSchemas.ByTxType(entry.TargetTx).ByNumber(entry.TargetField).Length;
                    string value = TelegramChainMap.Convert(entry, sourceValues, targetLength);

                    _currentValues[entry.TargetTx][entry.TargetField] = value;
                    if (value.Length > 0)
                        _chainedFields.Add(key);
                    else
                        _chainedFields.Remove(key); // 응답 필드가 공백이었다 — 채울 값이 없으므로 빈 칸(색 없음).
                    filledCount++;

                    // 목록에서 고르는 필드는 받은 목록도 함께 보관한다(그리드가 콤보 셀로 그린다).
                    if (entry.Conversion == TelegramChainConversion.SelectFirstFromList)
                        _chainListOptions[key] = TelegramChainMap.SplitInstallmentList(sourceValues[0]);
                }
                else
                {
                    _currentValues[entry.TargetTx][entry.TargetField] = string.Empty;
                    _chainedFields.Remove(key);
                    _chainListOptions.Remove(key);
                    clearedCount++;
                }
            }

            if (targetTxs.Count == 0)
                return; // 이 전문의 응답을 쓰는 연쇄 항목이 없다(예: 902614).

            // 4) 같은 전문 안에서 계산하는 항목 재계산.
            foreach (string targetTx in targetTxs)
                RecomputeWithinRequestEntries(targetTx);

            // 지금 보고 있는 그리드가 대상 전문이면 다시 그린다.
            if (_currentSchema != null && targetTxs.Contains(_currentSchema.TxType))
            {
                LoadGridForSchema(_currentSchema);
                UpdatePreview();
            }

            string targets = string.Join("·", targetTxs);
            _lblStatus.Text += response != null
                ? $" / 연쇄 적용: {sourceTx} 응답(#7=000)으로 {targets} 필드 {filledCount}개를 채움"
                : $" / 연쇄 해제: {sourceTx} 정상 응답(#7=000)이 아니어서 {targets}의 {sourceTx} 출처 필드 {clearedCount}개를 비움";
        }

        /// <summary>
        /// <paramref name="txType"/> 전문 안에서 계산하는 연쇄 항목(<see cref="TelegramChainEntry.IsWithinSameRequest"/>,
        /// 예: 902614 총 납부 금액 = 납부 세액 + 수수료)을 지금 값으로 다시 계산한다. 결과가 빈 칸이면
        /// "연쇄로 채워짐" 표시도 지운다. 그 전문이 화면에 떠 있으면 해당 셀도 갱신한다.
        /// </summary>
        private void RecomputeWithinRequestEntries(string txType)
        {
            var values = _currentValues[txType];
            foreach (var entry in TelegramChainMap.Entries)
            {
                if (!entry.IsWithinSameRequest || entry.TargetTx != txType)
                    continue;

                var sourceValues = entry.SourceFields
                    .Select(n => values.TryGetValue(n, out var v) ? v : string.Empty)
                    .ToList();
                int targetLength = TelegramSchemas.ByTxType(txType).ByNumber(entry.TargetField).Length;
                string value = TelegramChainMap.Convert(entry, sourceValues, targetLength);

                values[entry.TargetField] = value;
                if (value.Length > 0)
                    _chainedFields.Add((txType, entry.TargetField));
                else
                    _chainedFields.Remove((txType, entry.TargetField));

                if (_currentSchema != null && _currentSchema.TxType == txType)
                    RefreshGridValueCell(entry.TargetField, value);
            }
        }

        /// <summary>지금 그리드에서 필드 하나의 값 셀만 다시 채운다(값 + 연쇄 색). 이벤트는 발생시키지 않는다.</summary>
        private void RefreshGridValueCell(int fieldNumber, string value)
        {
            if (_currentSchema == null)
                return;

            bool previous = _suppressGridEvents;
            _suppressGridEvents = true;
            try
            {
                foreach (DataGridViewRow row in _grid.Rows)
                {
                    if (row.Tag is TelegramField field && field.Number == fieldNumber)
                    {
                        row.Cells[ColValue].Value = value;
                        row.Cells[ColValue].Style.BackColor = ValueCellColor(_currentSchema.TxType, fieldNumber);
                        break;
                    }
                }
            }
            finally
            {
                _suppressGridEvents = previous;
            }
        }

        /// <summary>
        /// 이 전문의 연쇄 필드 중 비어 있는 것이 있으면 상태 표시줄 안내 문구를 만든다(없으면 빈 문자열).
        /// </summary>
        private string DescribeEmptyChainFields(string txType)
        {
            if (!_currentValues.TryGetValue(txType, out var values))
                return string.Empty;

            int emptyCount = TelegramChainMap.Entries.Count(entry =>
                entry.TargetTx == txType
                && (!values.TryGetValue(entry.TargetField, out var v) || v.Length == 0));

            return emptyCount == 0
                ? string.Empty
                : $" / ※ 연쇄 필드 {emptyCount}개가 비어 있음(앞 전문 응답 전) — 빈 칸 그대로 보냄";
        }

        /// <summary>
        /// 응답 본문을 요청과 같은 스키마로 분해해 그리드에 나란히 채우고, <c>#7 응답 코드</c>를
        /// 해설하고, 902614 응답의 <c>#51</c>은 값 자체를 절대 화면에 찍지 않고 마스킹 문구로만
        /// 보여준다(PIN 관련 값은 화면에 찍지 않는다).
        /// </summary>
        private void ShowFieldDecomposition(TelegramSchema schema, byte[] requestBody, byte[] responseBody)
        {
            _responseGrid.Rows.Clear();

            if (responseBody.Length != schema.TotalLength)
            {
                // TelegramBuffer(schema, body) 생성자가 곧 예외를 던질 상황이므로, 필드 그리드
                // 분해는 여기서 포기한다(예외를 그대로 밖으로 던지지 않는다). 다만 E41(알 수 없는
                // 거래구분) 등 원캡 오류 응답은 공통부 70바이트만 오는 게 정상이라 이 분기를 가장
                // 자주 타는 것이 바로 그 케이스다. #7(POSITION=20, 길이=3)은 3전문 공통부에 공유되는
                // 고정 위치이므로, 본문이 그 위치까지만 있어도 스키마 없이 직접 읽어 보여준다. 70바이트에도 못 미치는
                // 비정상 응답은 그마저도 안 되므로 그 사실을 그대로 알린다.
                const int responseCodePosition = 20;
                const int responseCodeLength = 3;
                if (responseBody.Length >= responseCodePosition + responseCodeLength)
                {
                    string rawCode = Cp949.GetString(responseBody, responseCodePosition, responseCodeLength).TrimEnd(' ');
                    _lblResponseCode.Text =
                        $"#7 응답 코드: \"{rawCode}\" — {ResponseCodeCatalog.Describe(rawCode)} " +
                        $"(응답 본문이 {responseBody.Length}바이트뿐이라 전체 필드 그리드 분해는 불가 — 기대 {schema.TotalLength}바이트)";
                    _lblResponseCode.ForeColor = rawCode == "000" ? Color.DarkGreen : Color.DarkRed;
                }
                else
                {
                    _lblResponseCode.Text =
                        $"#7 응답 코드: (응답 본문이 {responseBody.Length}바이트뿐이라 #7 위치(20~22)조차 읽을 수 없음 — " +
                        $"기대 {schema.TotalLength}바이트)";
                    _lblResponseCode.ForeColor = Color.DarkRed;
                }
                return;
            }

            var reqBuffer = new TelegramBuffer(schema, requestBody);
            var respBuffer = new TelegramBuffer(schema, responseBody);
            bool isCardApproval = schema.TxType == "902614";

            foreach (var field in schema.Fields.OrderBy(f => f.Number))
            {
                string requestValue = reqBuffer.Read(field.Number);
                string responseValueDisplay;
                bool isMaskedPinField = isCardApproval && field.Number == 51;
                bool isWarning = false;

                if (isMaskedPinField)
                {
                    // #51(암호화된 비밀번호 정보)은 값 자체를
                    // 화면(과 로그)에 절대 노출하지 않는다. 길이만으로 정상/경고를 판단한다.
                    string rawMasked = respBuffer.Read(field.Number); // 문자 계열이라 TrimEnd(' ')된 실값(또는 빈 문자열).
                    int byteLength = Cp949.GetByteCount(rawMasked);
                    if (byteLength == 0)
                    {
                        responseValueDisplay = "정상(공백)";
                    }
                    else
                    {
                        responseValueDisplay = $"경고: 길이 {byteLength}의 값이 실려 있음(값은 표시하지 않음)";
                        isWarning = true;
                    }
                }
                else
                {
                    responseValueDisplay = respBuffer.Read(field.Number);
                }

                int rowIndex = _responseGrid.Rows.Add(
                    field.Number,
                    field.Name,
                    DescribeSetLocation(field),
                    requestValue,
                    responseValueDisplay);

                var row = _responseGrid.Rows[rowIndex];
                bool differs = !isMaskedPinField && requestValue != responseValueDisplay;

                if (isWarning)
                {
                    // #51에 값이 실려 있는 것은 결함 정황이므로 강한 경고색으로 구분한다.
                    row.Cells[RespColResponseValue].Style.BackColor = Color.MistyRose;
                    row.Cells[RespColResponseValue].Style.ForeColor = Color.DarkRed;
                }
                else if (differs)
                {
                    // 원캡(또는 인터넷지로/VAN)이 요청과 다른 값으로 채운 필드 — 실제로 채워졌음을 강조.
                    row.Cells[RespColResponseValue].Style.BackColor = Color.LightYellow;
                }
            }

            string responseCode = respBuffer.Read(7);
            _lblResponseCode.Text = $"#7 응답 코드: \"{responseCode}\" — {ResponseCodeCatalog.Describe(responseCode)}";

            // 800000이고 #7 = M01이면 API 세부 응답코드(#27)도 풀어 붙인다.
            if (schema.TxType == "800000" && responseCode.Trim() == "M01")
            {
                string detailCode = respBuffer.Read(ResponseCodeCatalog.CardInfoDetailFieldNumber).Trim();
                _lblResponseCode.Text += detailCode.Length == 0
                    ? " / 세부 코드 없음"
                    : $" / 세부 {detailCode} · {ResponseCodeCatalog.DescribeCardInfoDetail(detailCode) ?? "정의되지 않은 코드"}";
            }

            _lblResponseCode.ForeColor = responseCode.Trim() == "000" ? Color.DarkGreen : Color.DarkRed;

            if (isCardApproval)
            {
                string rawPin = respBuffer.Read(51);
                _lblField51Warning.Text = Cp949.GetByteCount(rawPin) == 0
                    ? "#51(암호화된 비밀번호 정보): 정상(공백)"
                    : $"#51(암호화된 비밀번호 정보): 경고 — 길이 {Cp949.GetByteCount(rawPin)}의 값이 실려 있음(값은 표시하지 않음 — 응답에는 실리지 않아야 함)";
                _lblField51Warning.ForeColor = Cp949.GetByteCount(rawPin) == 0 ? Color.DarkGreen : Color.DarkRed;
            }
            else
            {
                _lblField51Warning.Text = string.Empty;
            }
        }

        /// <summary>
        /// "직전 거래 상태 조회"(999999) 버튼 핸들러. 다른 3개 전문 버튼
        /// (<see cref="SelectSchema"/>)과 동일하게 스키마 전환 + 그리드 채우기만 하고, 실제 전송은
        /// "전송" 버튼(<see cref="OnSendClickAsync"/>)에 맡긴다.
        ///
        /// #9(요청기관 전문 관리 번호)는 원캡이 이 값으로 원거래를 찾으므로, 편의상
        /// 직전 실제 거래(<see cref="_lastRequestSchema"/>/<see cref="_lastRequestBody"/>)에 썼던
        /// 값을 그대로 미리 채워 둔다 — 가장 흔한 시나리오(방금 보낸 거래를 그대로 조회)를 한 번에
        /// 되도록 하되, 그리드는 여전히 편집 가능하므로 사용자가 값을 바꿔 "원거래 불일치"(E07)
        /// 케이스도 자유롭게 테스트할 수 있다. 직전 실제 거래가 아직 없으면(프로그램 시작 직후)
        /// 프리셋 기본값(빈 문자열)을 그대로 두고 사용자가 직접 채우게 한다.
        ///
        /// <see cref="_priorTransactionSchema"/>/<see cref="_priorTransactionBody"/>에 이 시점의
        /// <see cref="_lastRequestSchema"/>/<see cref="_lastRequestBody"/>를 스냅샷해 둔다 — 조회
        /// 전문을 실제로 전송하면 <see cref="OnSendClickAsync"/>가 그 필드들을 조회 전문(999999)
        /// 자신으로 덮어써 버리므로, 응답을 원거래 스키마로 재분해할 때(<see cref="ShowStatusInquiryResult"/>)
        /// "실제로 보냈던 원거래 요청값"과 비교하려면 여기서 미리 보관해 둬야 한다.
        /// </summary>
        private void SelectStatusInquirySchema()
        {
            _priorTransactionSchema = _lastRequestSchema;
            _priorTransactionBody = _lastRequestBody;

            SelectSchema(TelegramSchemas.StatusInquiryRequest);

            if (_priorTransactionSchema != null && _priorTransactionBody != null)
            {
                try
                {
                    var priorBuffer = new TelegramBuffer(_priorTransactionSchema, _priorTransactionBody);
                    SetGridFieldValue(9, priorBuffer.Read(9));
                }
                catch
                {
                    // 직전 요청에서 #9를 못 읽으면(이례적) 프리셋 기본값 그대로 두고 사용자가 직접 채우게 한다.
                }
            }
        }

        /// <summary>
        /// 그리드에서 해당 필드 번호의 값 셀을 찾아 값을 채우고, <see cref="Grid_CellValueChanged"/>와
        /// 동일하게 <see cref="_currentValues"/>/미리보기에도 반영한다. <see cref="SelectStatusInquirySchema"/>가
        /// #9를 코드에서 미리 채워 넣을 때 쓴다(사용자가 그리드 셀을 직접 편집한 것과 동일한 효과).
        /// </summary>
        private void SetGridFieldValue(int fieldNumber, string value)
        {
            if (_currentSchema == null)
                return;

            foreach (DataGridViewRow row in _grid.Rows)
            {
                if (row.Tag is TelegramField field && field.Number == fieldNumber)
                {
                    row.Cells[ColValue].Value = value;
                    break;
                }
            }

            _currentValues[_currentSchema.TxType][fieldNumber] = value;
            UpdatePreview();
        }

        /// <summary>
        /// 조회 응답(고정부 80바이트 + 가변 꼬리)을 분해해 보여준다. 고정부는 #7/#14/#15만 봉투
        /// 라벨(<see cref="_lblStatusInquiryEnvelope"/>)로 보여주고, 꼬리(원거래 응답 원문)가 있으면
        /// #14 값으로 원거래 스키마를 찾아 <see cref="ShowFieldDecomposition"/>을 그대로 재사용해
        /// 기존 필드 분해 그리드/코드 해설/#51 마스킹을 그대로 활용한다.
        ///
        /// 봉투의 #7은 "조회 자체가 성공(직전 거래를 찾음)"만 뜻한다(찾으면
        /// 고정 "000", 못 찾으면 "E07"). 원거래가 실제로 승인/거절이었는지는 이 #7과 무관하며, 아래
        /// 필드 분해 그리드가 꼬리를 원거래 스키마로 다시 파싱해 보여주는 "그 스키마 자신의 #7"에서
        /// 확인해야 한다 — 봉투의 #7과 꼬리 안의 #7은 서로 다른 값일 수 있다.
        /// </summary>
        private void ShowStatusInquiryResult(byte[] responseBody)
        {
            if (responseBody.Length < 80)
            {
                _lblStatusInquiryEnvelope.Text =
                    $"조회 응답 고정부(80바이트) 미달 — 실제 {responseBody.Length}바이트.";
                _lblStatusInquiryEnvelope.ForeColor = Color.DarkRed;
                return;
            }

            var fixedBytes = new byte[80];
            Array.Copy(responseBody, fixedBytes, 80);
            var fixedBuffer = new TelegramBuffer(TelegramSchemas.StatusInquiryResponseFixedPart, fixedBytes);

            string code7 = fixedBuffer.Read(7).TrimEnd(' ');
            string originalType = fixedBuffer.Read(TelegramSchemas.StatusInquiryOriginalTypeFieldNumber);
            string originalLengthRaw = fixedBuffer.Read(TelegramSchemas.StatusInquiryOriginalLengthFieldNumber);
            int.TryParse(originalLengthRaw, out int originalLength);
            int tailLength = responseBody.Length - 80;

            // 이 #7은 "조회 자체 성공 여부"일 뿐 원거래 승인/거절과 무관하다
            // (클래스 요약 참고). 아래 라벨 문구도 그 의미로 고정한다.
            _lblStatusInquiryEnvelope.Text =
                $"[조회 응답 고정부] #7 응답 코드=\"{code7}\"(조회 자체 성공 여부 — {(code7 == "000" ? "매칭됨" : "매칭 안 됨")}) / " +
                $"#14 원거래 거래구분=\"{originalType}\" / #15 원거래 응답 전문 길이=\"{originalLengthRaw}\"({originalLength}) / " +
                $"실제 꼬리 길이={tailLength}바이트 (원거래 승인/거절은 아래 필드 분해의 원거래 #7에서 확인)";
            _lblStatusInquiryEnvelope.ForeColor = code7 == "000" ? Color.DarkGreen : Color.DarkRed;

            if (tailLength <= 0)
            {
                // 결과 없음(E07 등) — 원거래 원문이 없으므로 그 아래 필드 분해는 생략한다.
                return;
            }

            var tail = new byte[tailLength];
            Array.Copy(responseBody, 80, tail, 0, tailLength);

            TelegramSchema originalSchema;
            try
            {
                originalSchema = TelegramSchemas.ByTxType(originalType);
            }
            catch (Exception ex)
            {
                _responseTextBox.Text = Cp949.GetString(tail);
                _lblResponseCode.Text = $"#14 원거래 거래구분(\"{originalType}\")으로 스키마를 찾지 못함 — {ex.Message}";
                _lblResponseCode.ForeColor = Color.DarkRed;
                return;
            }

            if (tail.Length != originalSchema.TotalLength)
            {
                _responseTextBox.Text = Cp949.GetString(tail);
                _lblResponseCode.Text = $"꼬리 길이({tailLength}바이트)가 {originalSchema.TxType} 스키마 총 길이" +
                    $"({originalSchema.TotalLength}바이트)와 다르다 — 필드 분해 불가.";
                _lblResponseCode.ForeColor = Color.DarkRed;
                return;
            }

            // 키오스크는 기존 파서를 재사용하면 된다 — 원거래와 같은 스키마이면 조회 버튼을
            // 누르던 시점에 스냅샷해 둔 원거래 요청 본문(_priorTransactionBody — 조회 전문 전송 시
            // _lastRequestBody는 이미 999999 자신으로 덮어써진 뒤라 여기선 쓸 수 없다)을 나란히 놓고 기존 ShowFieldDecomposition을 그대로 재사용한다
            // (파서를 새로 만들지 않는다).
            byte[] requestForDiff = _priorTransactionSchema != null
                && _priorTransactionSchema.TxType == originalSchema.TxType
                && _priorTransactionBody != null
                    ? _priorTransactionBody
                    : new TelegramBuffer(originalSchema).ToBytes(); // 스키마가 다른 이례적인 경우엔 빈 요청으로만 비교.

            ShowFieldDecomposition(originalSchema, requestForDiff, tail);
        }
    }
}
